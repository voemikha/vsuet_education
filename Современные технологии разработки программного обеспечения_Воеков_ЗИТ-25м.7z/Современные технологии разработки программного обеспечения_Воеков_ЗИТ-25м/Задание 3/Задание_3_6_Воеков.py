num = int(input("Введите число для переменной num: "))

if num % 7 == 0:
    print(f"Число {num} кратно 7")
else:
    print(f"Число {num} не кратно 7")