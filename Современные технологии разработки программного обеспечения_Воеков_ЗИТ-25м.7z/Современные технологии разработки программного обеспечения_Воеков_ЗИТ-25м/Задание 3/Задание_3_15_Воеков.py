num_1 = int(input("Введите число для переменной num_1: "))
num_2 = int(input("Введите число для переменной num_2: "))

summ = num_1 + num_2
diff = num_1 - num_2

print(f'Сумма чисел {num_1} и {num_2} = {summ}')
print(f'Разность чисел {num_1} и {num_2} = {diff}')