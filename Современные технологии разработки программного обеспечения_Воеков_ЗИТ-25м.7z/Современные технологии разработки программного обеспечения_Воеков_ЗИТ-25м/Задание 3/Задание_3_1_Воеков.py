num_1, num_2 = int(input("Введите число для переменной num_1: ")), int(input("Введите число для переменной num_2: "))
if num_1 > num_2:
    print(num_1)
elif num_1 < num_2:
    print(num_2)
else:
    print("Числа равны")
