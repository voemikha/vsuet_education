num_1 = int(input("Введите число для переменной num_1: "))
num_2 = int(input("Введите число для переменной num_2: "))
num_3 = int(input("Введите число для переменной num_3: "))

if num_1 == num_2 and num_1 == num_3:
    print("Все три числа равны")
else:
    print("Числа неравны")