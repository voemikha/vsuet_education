# Задание 2.1
import math

x = float(input("Введение значение переменной х: "))
y = float(input("Введение значение переменной y: "))
z = float(input("Введение значение переменной z: "))

s = (2 * math.cos(x - 2 / 3)) / (0.5 + math.sin(y) ** 2) * (1 + (z**2 / (3 - z**2 / 5)))

print("Результат: ", round(s, 6))


# Задание 2.2
x = float(input("Введение значение переменной х: "))
y = float(input("Введение значение переменной y: "))
z = float(input("Введение значение переменной z: "))

import math

s = ((9 + (x - y)**2) ** (1/3)) / (x**2 + y**2 + 2) - math.exp(abs(x - y)) * (math.tan(z) ** 3)

print("Результат: ", round(s, 5))